package com.hexaware.exception;

public class SalaryCalculationException extends Exception {
    public SalaryCalculationException(String message) {
        super(message);
    }
}
